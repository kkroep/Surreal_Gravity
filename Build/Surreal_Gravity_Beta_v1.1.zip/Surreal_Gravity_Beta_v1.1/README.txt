*********************Alpha manual Surreal Gravity*************************

**************
*CONTROLS*
**************

The controls of the game can be found under:
Settings > Instructions


*************
*MULTIPLAYER*
*************

For multiplayer you need players with different accounts (up to 4).
You can login by:

account > fill in username > fill in password > click login

The accounts currently available are:

usrname/psswrd:

Kees/Kees
Coen/Coen
Steven/Steven
Ayyoeb/Ayyoeb
Kwok/Kwok
Roberto/Roberto
AB/BA
Earless/WADAFA

If you want, you can register your own account!

When you are logged in you can make a server by:
	Multiplayer > start server
Another player with a different account can then access the server by:
	Multiplayer > refresh > #names's server
The client will appear in the lobby. The Server can start the game with <start game>

Note that you can't join a server which has already begun!

You can exit the lobby by clicking the disconnect option. If you are a client, the lobby remains intact. If you are a server, however, everyone gets kicked out of the lobby.
You can exit the game at any time, while playing the game, by pressing the escape key. If you are a client, the rest can play on. If you are a server, however, everyone will return to the main menu.

*****new:
TAB to see scorescreen when playing multiplayer




